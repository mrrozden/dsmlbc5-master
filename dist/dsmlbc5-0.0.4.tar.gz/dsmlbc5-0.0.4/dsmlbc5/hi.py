def hello():
    print("Hej Hej!")

def hello2():
    print("Hello")

def hello3():
    print("SA")

def hello4():
    print("Hola")

